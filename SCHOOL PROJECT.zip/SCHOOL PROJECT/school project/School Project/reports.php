<?php
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}

$reportType = isset($_GET['report_type']) ? $_GET['report_type'] : '';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Generate Reports - Admin</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"/>
    <style>
        /* Global styling */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fafafa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main container styling */
        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        /* Back arrow link */
        .back-link {
            text-decoration: none;
            font-size: 1.1rem;
            color: #007BFF;
            display: inline-flex;
            align-items: center;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        /* Heading styling */
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        h2 i {
            color: #007BFF;
            margin-right: 10px;
        }
        /* Form styling */
        form.report-form {
            max-width: 400px;
            margin: 0 auto 30px auto;
            text-align: center;
        }
        form.report-form select,
        form.report-form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }
        form.report-form select:hover,
        form.report-form select:focus {
            border-color: #007BFF;
            outline: none;
        }
        form.report-form input[type="submit"] {
            background: #007BFF;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        form.report-form input[type="submit"]:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }
        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        table th, table td {
            padding: 10px 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        table th {
            background-color: #007BFF;
            color: #fff;
        }
        /* Heading for report output */
        .report-heading {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
  
        <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        
        <h2><i class="fas fa-chart-line"></i> Generate Reports</h2>

        <form method="GET" action="" class="report-form">
            <select name="report_type" required>
                <option value="">-- Select Report Type --</option>
                <option value="financial" <?php if($reportType=="financial") echo "selected"; ?>>Financial Report</option>
                <option value="attendance" <?php if($reportType=="attendance") echo "selected"; ?>>Attendance Report</option>
                <option value="performance" <?php if($reportType=="performance") echo "selected"; ?>>Student Performance Report</option>
            </select>
            <input type="submit" value="Generate Report">
        </form>
        
        <?php
        if ($reportType == "financial") {
            
            $stmt = $pdo->query("SELECT SUM(amount) AS total_collected FROM fee_payments WHERE paid_date IS NOT NULL");
            $result = $stmt->fetch();
            $totalCollected = $result['total_collected'] !== null ? $result['total_collected'] : 0;
            
            $stmt2 = $pdo->query("SELECT SUM(amount) AS total_outstanding FROM fee_payments WHERE paid_date IS NULL");
            $result2 = $stmt2->fetch();
            $totalOutstanding = $result2['total_outstanding'] !== null ? $result2['total_outstanding'] : 0;
            
            echo "<h3 class='report-heading'>Financial Report</h3>";
            echo "<table>";
            echo "<tr><th>Total Collected</th><th>Total Outstanding</th></tr>";
            echo "<tr><td>$totalCollected</td><td>$totalOutstanding</td></tr>";
            echo "</table>";
            

            $stmt3 = $pdo->query("SELECT * FROM fee_payments ORDER BY fee_id DESC");
            $fees = $stmt3->fetchAll();
            if(count($fees) > 0) {
                echo "<h4 class='report-heading'>Fee Payment Transactions</h4>";
                echo "<table>";
                echo "<tr>
                          <th>Fee ID</th>
                          <th>Student ID</th>
                          <th>Amount</th>
                          <th>Due Date</th>
                          <th>Paid Date</th>
                          <th>Invoice Number</th>
                      </tr>";
                foreach ($fees as $fee) {
                    echo "<tr>";
                    echo "<td>".$fee['fee_id']."</td>";
                    echo "<td>".htmlspecialchars($fee['student_id'])."</td>";
                    echo "<td>".htmlspecialchars($fee['amount'])."</td>";
                    echo "<td>".htmlspecialchars($fee['due_date'])."</td>";
                    echo "<td>".htmlspecialchars($fee['paid_date'])."</td>";
                    echo "<td>".htmlspecialchars($fee['invoice_number'])."</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No fee payment records available.</p>";
            }
        } else if ($reportType == "attendance") {
         
            echo "<h3 class='report-heading'>Attendance Report</h3>";
            try {
                $stmt = $pdo->query("SELECT student_id, 
                                       SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) AS total_present, 
                                       SUM(CASE WHEN status='absent' THEN 1 ELSE 0 END) AS total_absent
                                       FROM attendance
                                       GROUP BY student_id");
                $attendanceData = $stmt->fetchAll();
                if (count($attendanceData) > 0) {
                    echo "<table>";
                    echo "<tr><th>Student ID</th><th>Total Present</th><th>Total Absent</th></tr>";
                    foreach($attendanceData as $att) {
                        echo "<tr>";
                        echo "<td>".htmlspecialchars($att['student_id'])."</td>";
                        echo "<td>".htmlspecialchars($att['total_present'])."</td>";
                        echo "<td>".htmlspecialchars($att['total_absent'])."</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<p>No attendance data available.</p>";
                }
            } catch (PDOException $e) {
                echo "<p>Error generating attendance report: " . $e->getMessage() . "</p>";
            }
        } else if ($reportType == "performance") {
     
            echo "<h3 class='report-heading'>Student Performance Report</h3>";
            try {
                $stmt = $pdo->query("SELECT student_id, subject, grade, remarks FROM report_cards ORDER BY student_id, subject");
                $performanceData = $stmt->fetchAll();
                if(count($performanceData) > 0) {
                    echo "<table>";
                    echo "<tr><th>Student ID</th><th>Subject</th><th>Grade</th><th>Remarks</th></tr>";
                    foreach ($performanceData as $perf) {
                        echo "<tr>";
                        echo "<td>".htmlspecialchars($perf['student_id'])."</td>";
                        echo "<td>".htmlspecialchars($perf['subject'])."</td>";
                        echo "<td>".htmlspecialchars($perf['grade'])."</td>";
                        echo "<td>".htmlspecialchars($perf['remarks'])."</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<p>No performance data available.</p>";
                }
            } catch (PDOException $e) {
                echo "<p>Error generating performance report: " . $e->getMessage() . "</p>";
            }
        }
        ?>
    </div>
</body>
</html>
