<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header("Location: index.php");
    exit;
}

$error = "";
$child = [];
$reportCards = [];
$student_id = "";


if (isset($_SESSION['student_id']) && !empty($_SESSION['student_id'])) {
    $student_id = $_SESSION['student_id'];
} else {
    $error = "No child is linked with your account. Please contact the school.";
}

if (empty($error) && !empty($student_id)) {

    $stmt = $pdo->prepare("SELECT student_id, student_name FROM students WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $child = $stmt->fetch();

    if (!$child) {
        $error = "Child record not found.";
    } else {

        $stmt2 = $pdo->prepare("SELECT subject, grade, remarks FROM report_cards WHERE student_id = ? ORDER BY subject ASC");
        $stmt2->execute([$student_id]);
        $reportCards = $stmt2->fetchAll();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Child Report Card</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e0eafc);
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
            color: #007BFF;
            font-size: 1.1rem;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }
        .subheading {
            text-align: center;
            color: #555;
            margin-bottom: 20px;
        }
        .error {
            text-align: center;
            color: red;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        .message {
            text-align: center;
            color: green;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
      
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2><i class="fas fa-book-reader"></i> Child Report Card</h2>
        
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if (empty($error) && !empty($child)): ?>
            <div class="subheading">
                Report Card for <strong><?php echo htmlspecialchars($child['student_name']); ?></strong> (ID: <?php echo htmlspecialchars($child['student_id']); ?>)
            </div>
            <?php if (count($reportCards) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Grade</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reportCards as $entry): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($entry['subject']); ?></td>
                                <td><?php echo htmlspecialchars($entry['grade']); ?></td>
                                <td><?php echo htmlspecialchars($entry['remarks']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="message">No report card records found for your child.</div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>
