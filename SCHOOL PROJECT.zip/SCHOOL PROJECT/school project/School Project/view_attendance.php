<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['student', 'parent', 'teacher'])) {
    header("Location: index.php");
    exit;
}

$error = "";
$attendanceRecords = [];
$student_id = null;
$role = $_SESSION['role'];


if ($role === 'student') {
    if (isset($_SESSION['student_id'])) {
        $student_id = $_SESSION['student_id'];
    } else {
   
        $stmtStudent = $pdo->prepare("SELECT student_id FROM students WHERE user_id = ? LIMIT 1");
        $stmtStudent->execute([$_SESSION['user_id']]);
        $studentRec = $stmtStudent->fetch();
        if ($studentRec) {
            $student_id = $studentRec['student_id'];
          
            $_SESSION['student_id'] = $student_id;
        } else {
            $error = "Student record not found in your account.";
        }
    }
} elseif ($role === 'parent') {

    if (isset($_SESSION['student_id'])) {
        $student_id = $_SESSION['student_id'];
    } else {
        $error = "No student is linked with your account. Please contact the school.";
    }
} elseif ($role === 'teacher') {
   
    if (isset($_GET['student_id']) && !empty($_GET['student_id'])) {
        $student_id = $_GET['student_id'];
    } else {
        $error = "No student selected. Please select a student to view the attendance records.";
    }
}

if (!empty($student_id) && empty($error)) {
    $stmt = $pdo->prepare("SELECT date, status FROM attendance WHERE student_id = ? ORDER BY date DESC");
    $stmt->execute([$student_id]);
    $attendanceRecords = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Attendance</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
         body {
             font-family: Arial, sans-serif;
             background: linear-gradient(135deg, #f8f9fa, #e0eafc);
             margin: 0;
             padding: 20px;
         }
         .container {
             max-width: 800px;
             margin: 0 auto;
             background: #fff;
             padding: 20px;
             border-radius: 8px;
             box-shadow: 0 0 10px rgba(0,0,0,0.1);
         }
         .back-link {
             display: inline-block;
             margin-bottom: 20px;
             text-decoration: none;
             color: #007BFF;
             font-size: 1.1rem;
             transition: transform 0.3s ease;
         }
         .back-link i {
             margin-right: 5px;
         }
         .back-link:hover {
             transform: translateX(-5px);
         }
         h2 {
             text-align: center;
             color: #333;
             margin-bottom: 20px;
         }
         .error {
             color: red;
             text-align: center;
             font-size: 1.1rem;
             margin-bottom: 20px;
         }
         .message {
             color: green;
             text-align: center;
             font-size: 1.1rem;
             margin-bottom: 20px;
         }
         table {
             width: 100%;
             border-collapse: collapse;
             margin-bottom: 20px;
         }
         table, th, td {
             border: 1px solid #ddd;
         }
         th, td {
             padding: 10px;
             text-align: center;
         }
         th {
             background: #007BFF;
             color: #fff;
         }
    </style>
</head>
<body>
    <div class="container">
       
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2><i class="fas fa-eye"></i> View Attendance</h2>
        
        <?php if(!empty($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if(empty($error) && count($attendanceRecords) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($attendanceRecords as $record): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($record['date']); ?></td>
                        <td><?php echo htmlspecialchars($record['status']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php elseif(empty($error)): ?>
            <div class="message">No attendance records found.</div>
        <?php endif; ?>
    </div>
</body>
</html>
