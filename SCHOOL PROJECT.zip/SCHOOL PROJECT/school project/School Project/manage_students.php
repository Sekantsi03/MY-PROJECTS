<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    if (isset($_POST['update'])) {
        $student_id = $_POST['student_id'];
        $class_id = $_POST['class_id'];
        $academic_details = $_POST['academic_details'];
        $stmt = $pdo->prepare("UPDATE students SET class_id = ?, academic_details = ? WHERE student_id = ?");
        $stmt->execute([$class_id, $academic_details, $student_id]);
        $message = "Student record updated successfully!";
    }
    
   
    if (isset($_POST['clear'])) {
        $student_id = $_POST['student_id'];
        $stmt = $pdo->prepare("UPDATE students SET class_id = NULL, academic_details = NULL WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $message = "Student record details cleared successfully!";
    }
}

$stmt = $pdo->query("SELECT * FROM students");
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Students - Admin</title>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        /* Global styling with a light gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fafafa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main container styling */
        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        /* Back arrow styling */
        .back-link {
            text-decoration: none;
            font-size: 1.1rem;
            color: #007BFF;
            display: inline-flex;
            align-items: center;
            margin-bottom: 10px;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        /* Heading style with an icon */
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        h2 i {
            color: #007BFF;
            margin-right: 10px;
        }
        /* Message styling */
        .message {
            text-align: center;
            font-size: 1.1rem;
            color: green;
            margin-bottom: 20px;
        }
        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            padding: 10px 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #007BFF;
            color: #fff;
        }
        /* Input and textarea styling for inline update form */
        input[type="text"], textarea {
            width: 90%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        /* Buttons styling with hover effects */
        input[type="submit"] {
            padding: 6px 12px;
            background: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            margin: 2px;
        }
        input[type="submit"]:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        .clear-btn {
            background: #dc3545;
        }
        .clear-btn:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        
        <h2><i class="fas fa-user-graduate"></i> Manage Students</h2>
        <?php if ($message != ''): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        
        <table>
            <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Class ID</th>
                <th>Academic Details</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($students as $student): ?>
            <tr>
                <form method="POST" action="">
                    <td>
                        <?php echo $student['student_id']; ?>
                        <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                    </td>
                    <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                    <td>
                        <input type="text" name="class_id" value="<?php echo htmlspecialchars($student['class_id']); ?>" placeholder="Enter Class ID">
                    </td>
                    <td>
                        <textarea name="academic_details" rows="2" placeholder="Academic Details"><?php echo htmlspecialchars($student['academic_details']); ?></textarea>
                    </td>
                    <td>
                        <input type="submit" name="update" value="Update">
                        <input type="submit" name="clear" value="Clear" class="clear-btn">
                    </td>
                </form>
            </tr>
            <?php endforeach; ?>
        </table>        
    </div>
</body>
</html>
