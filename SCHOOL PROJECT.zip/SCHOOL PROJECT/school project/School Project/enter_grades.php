<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: index.php");
    exit;
}

$loggedInUserId = $_SESSION['user_id'];

$stmtTeacher = $pdo->prepare("SELECT assigned_class, subject, teacher_name FROM teachers WHERE user_id = ?");
$stmtTeacher->execute([$loggedInUserId]);
$teacher = $stmtTeacher->fetch();

if (!$teacher || empty($teacher['assigned_class'])) {
    $error = "No class assigned to you. Please contact the administrator.";
} else {
    $classID = $teacher['assigned_class'];
    $teacherSubject = $teacher['subject'];
    $stmtStudents = $pdo->prepare("SELECT student_id, student_name FROM students WHERE class_id = ?");
    $stmtStudents->execute([$classID]);
    $students = $stmtStudents->fetchAll();
}

$message = "";


if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit_grades'])) {
   
    $gradeData = $_POST['grade'];
    $remarksData = $_POST['remarks'];
    

    foreach ($gradeData as $student_id => $grade) {
  
        $grade = trim($grade);
        $remarks = isset($remarksData[$student_id]) ? trim($remarksData[$student_id]) : "";
        
       
        if (!empty($grade)) {
            
            $stmtCheck = $pdo->prepare("SELECT report_id FROM report_cards WHERE student_id = ? AND subject = ?");
            $stmtCheck->execute([$student_id, $teacherSubject]);
            
            if ($stmtCheck->rowCount() > 0) {
              
                $stmtUpdate = $pdo->prepare("UPDATE report_cards SET grade = ?, remarks = ? WHERE student_id = ? AND subject = ?");
                $stmtUpdate->execute([$grade, $remarks, $student_id, $teacherSubject]);
            } else {
                
                $stmtInsert = $pdo->prepare("INSERT INTO report_cards (student_id, subject, grade, remarks) VALUES (?, ?, ?, ?)");
                $stmtInsert->execute([$student_id, $teacherSubject, $grade, $remarks]);
            }
        }
    }
    $message = "Grades recorded successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Enter Grades - Teacher</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
    <style>
        /* Global styling with a soft gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fafafa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main container styling */
        .container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        /* Back link styling */
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
            color: #007BFF;
            font-size: 1.1rem;
            transition: transform 0.3s;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        /* Heading styling */
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }
        .subheading {
            text-align: center;
            color: #555;
            margin-bottom: 20px;
        }
        /* Message and error styling */
        .message {
            text-align: center;
            color: green;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        .error {
            text-align: center;
            color: red;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #007BFF;
            color: #fff;
        }
        /* Input field styling within table */
        input[type="text"] {
            width: 90%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        /* Submit button styling */
        input[type="submit"] {
            background: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 25px;
            font-size: 1rem;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        input[type="submit"]:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
       
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2><i class="fas fa-graduation-cap"></i> Enter Grades</h2>
        <div class="subheading">
            <?php
            if (isset($teacher) && !empty($teacher['assigned_class'])) {
                echo "Assigned Class: " . htmlspecialchars($teacher['assigned_class']) . " | Subject: " . htmlspecialchars($teacher['subject']);
            }
            ?>
        </div>
        
        <?php
        if (isset($error)) {
            echo "<div class='error'>" . htmlspecialchars($error) . "</div>";
        }
        if ($message != "") {
            echo "<div class='message'>" . htmlspecialchars($message) . "</div>";
        }
        ?>
        
        <?php if (!isset($error) && count($students) > 0): ?>
            <form method="POST" action="">
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Grade</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                <td>
                                    <input type="text" name="grade[<?php echo $student['student_id']; ?>]" placeholder="Enter grade" required>
                                </td>
                                <td>
                                    <input type="text" name="remarks[<?php echo $student['student_id']; ?>]" placeholder="Optional remarks">
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div style="text-align: center;">
                    <input type="submit" name="submit_grades" value="Submit Grades">
                </div>
            </form>
        <?php elseif (!isset($error)): ?>
            <p>No students found for your assigned class.</p>
        <?php endif; ?>
    </div>
</body>
</html>
