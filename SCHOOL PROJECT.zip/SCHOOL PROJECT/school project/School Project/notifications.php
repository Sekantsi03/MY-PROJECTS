<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user_id = trim($_POST['user_id']);  
    $notif_type = trim($_POST['notif_type']);
    $notif_message = trim($_POST['notif_message']);
    
    
    if ($user_id == '') { 
        $stmt = $pdo->query("SELECT id, email FROM users");
        $users = $stmt->fetchAll();
        foreach ($users as $user) {
          
            $stmtInsert = $pdo->prepare("INSERT INTO notifications (user_id, message, notification_type) VALUES (?, ?, ?)");
            $stmtInsert->execute([$user['id'], $notif_message, $notif_type]);
            
            
            $to = $user['email'];
            $subject = "School Notification - " . ucfirst($notif_type);
            $headers = "From: no-reply@malutischool.com";

            mail($to, $subject, $notif_message, $headers);
        }
        $message = "Broadcast notifications sent successfully!";
    } else {
        
        $stmtInsert = $pdo->prepare("INSERT INTO notifications (user_id, message, notification_type) VALUES (?, ?, ?)");
        $stmtInsert->execute([$user_id, $notif_message, $notif_type]);
        
        $stmtEmail = $pdo->prepare("SELECT email FROM users WHERE id = ?");
        $stmtEmail->execute([$user_id]);
        $recipient = $stmtEmail->fetch();
        if ($recipient) {
            $to = $recipient['email'];
            $subject = "School Notification - " . ucfirst($notif_type);
            $headers = "From: no-reply@malutischool.com";
            mail($to, $subject, $notif_message, $headers);
        }
        $message = "Notification sent successfully to user ID: " . htmlspecialchars($user_id);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Send Notifications - Admin</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"/>
    <style>
        /* Global body styling with a gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main container */
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        /* Back arrow link styling */
        .back-link {
            text-decoration: none;
            font-size: 1.1rem;
            color: #007BFF;
            display: inline-flex;
            align-items: center;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        /* Heading styling */
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        h2 i {
            color: #007BFF;
            margin-right: 10px;
        }
        /* Message styling */
        .message {
            text-align: center;
            font-size: 1.1rem;
            color: green;
            margin-bottom: 20px;
        }
        /* Notification form styling */
        form.notification-form {
            max-width: 500px;
            margin: 0 auto;
        }
        form.notification-form label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }
        form.notification-form input[type="text"],
        form.notification-form textarea,
        form.notification-form select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }
        form.notification-form input[type="text"]:hover,
        form.notification-form input[type="text"]:focus,
        form.notification-form textarea:hover,
        form.notification-form textarea:focus,
        form.notification-form select:hover,
        form.notification-form select:focus {
            border-color: #007BFF;
            outline: none;
        }
        form.notification-form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        form.notification-form input[type="submit"]:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">

        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        
        <h2><i class="fas fa-bell"></i> Send Notifications</h2>
        <?php if ($message != ''): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="" class="notification-form">
            <label for="notif_type">Notification Type:</label>
            <select name="notif_type" id="notif_type" required>
                <option value="">Select Notification Type</option>
                <option value="announcement">Announcement</option>
                <option value="fee_reminder">Fee Reminder</option>
                <option value="report">Report</option>
            </select>
            
            <label for="user_id">User ID (leave blank for broadcast):</label>
            <input type="text" name="user_id" id="user_id" placeholder="Enter user ID for specific notification">
            
            <label for="notif_message">Message:</label>
            <textarea name="notif_message" id="notif_message" rows="4" placeholder="Enter notification message" required></textarea>
            
            <input type="submit" value="Send Notification">
        </form>
    </div>
</body>
</html>
