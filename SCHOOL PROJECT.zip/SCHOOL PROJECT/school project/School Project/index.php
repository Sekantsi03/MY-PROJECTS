<?php
require 'config.php';


if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];


    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        
        
        header("Location: dashboard.php");
        exit;
    } else {
        $message = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Maluti School Management - Login</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        /* Global reset and body styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        /* Main container styling */
        .login-container {
            width: 350px;
            margin: 80px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }
        /* Heading with icon */
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        h2 i {
            margin-right: 8px;
            color: #007BFF;
        }
        /* Error/success message styling */
        .message {
            text-align: center;
            color: red;
            margin-bottom: 15px;
        }
        /* Input group for adding icons inside inputs */
        .input-group {
            position: relative;
            margin-bottom: 15px;
        }
        .input-group i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .input-group input {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s ease;
        }
        .input-group input:hover,
        .input-group input:focus {
            border-color: #007BFF;
            outline: none;
        }
        /* Submit button styling with hover effect */
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background: #007BFF;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        input[type="submit"]:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }
        /* Link styling */
        p {
            text-align: center;
            margin-top: 15px;
        }
        p a {
            text-decoration: none;
            color: #007BFF;
            transition: color 0.3s ease;
        }
        p a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
   <div class="login-container">
     <a href="landing.html" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Home
	    </a>
       <h2><i class="fas fa-sign-in-alt"></i> Login</h2>
       <?php if ($message != '') { echo "<div class='message'>$message</div>"; } ?>
       <form method="POST" action="">
          <div class="input-group">
              <i class="fas fa-user"></i>
              <input type="text" name="username" placeholder="Username" required />
          </div>
          <div class="input-group">
              <i class="fas fa-lock"></i>
              <input type="password" name="password" placeholder="Password" required />
          </div>
          <input type="submit" value="Login" />
       </form>
       <p>New User? <a href="register.php"><i class="fas fa-user-plus"></i> Register Here</a></p>
   </div>
</body>
</html>
