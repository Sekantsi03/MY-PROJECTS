<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: index.php");
    exit;
}


$loggedInUserId = $_SESSION['user_id'];


$stmtTeacher = $pdo->prepare("SELECT assigned_class FROM teachers WHERE user_id = ?");
$stmtTeacher->execute([$loggedInUserId]);
$teacher = $stmtTeacher->fetch();

if (!$teacher || empty($teacher['assigned_class'])) {
    $error = "No class assigned to you. Please contact the administrator.";
} else {
    $classID = $teacher['assigned_class'];

    $stmtStudents = $pdo->prepare("SELECT student_id, student_name FROM students WHERE class_id = ?");
    $stmtStudents->execute([$classID]);
    $students = $stmtStudents->fetchAll();
}

$message = "";


if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit_attendance'])) {
  
    $attendanceData = $_POST['attendance'];
    $today = date("Y-m-d");
    
    foreach ($attendanceData as $student_id => $status) {
     
        $stmtCheck = $pdo->prepare("SELECT attendance_id FROM attendance WHERE student_id = ? AND date = ?");
        $stmtCheck->execute([$student_id, $today]);
        
        if ($stmtCheck->rowCount() > 0) {
            
            $stmtUpdate = $pdo->prepare("UPDATE attendance SET status = ? WHERE student_id = ? AND date = ?");
            $stmtUpdate->execute([$status, $student_id, $today]);
        } else {
            
            $stmtInsert = $pdo->prepare("INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)");
            $stmtInsert->execute([$student_id, $today, $status]);
        }
    }
    $message = "Attendance for {$today} recorded successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mark Attendance - Teacher</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
    <style>
        /* Global body styling with a soft gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fafafa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main container styling */
        .container {
            max-width: 800px;
            margin: 40px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        /* Back link styling */
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
            color: #007BFF;
            font-size: 1.1rem;
            transition: transform 0.3s;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        /* Headings and message styling */
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        .message {
            text-align: center;
            color: green;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        .error {
            text-align: center;
            color: red;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: #fff;
        }
        /* Submit button styling */
        input[type="submit"] {
            background: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 1rem;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        input[type="submit"]:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
   
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2><i class="fas fa-check-square"></i> Mark Attendance</h2>
        
        <?php if (isset($error)) { echo "<div class='error'>" . htmlspecialchars($error) . "</div>"; } ?>
        <?php if ($message != "") { echo "<div class='message'>" . htmlspecialchars($message) . "</div>"; } ?>
        
        <?php if (!isset($error) && count($students) > 0): ?>
            <form method="POST" action="">
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Present</th>
                            <th>Absent</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                <td>
                                    <input type="radio" name="attendance[<?php echo $student['student_id']; ?>]" value="present" required>
                                </td>
                                <td>
                                    <input type="radio" name="attendance[<?php echo $student['student_id']; ?>]" value="absent">
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <input type="submit" name="submit_attendance" value="Submit Attendance">
            </form>
        <?php elseif (!isset($error)): ?>
            <p>No students found for your assigned class.</p>
        <?php endif; ?>
    </div>
</body>
</html>
