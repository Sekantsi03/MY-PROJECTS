<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'student', 'parent'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'];
$student_id = null;
$error = "";
$student = [];
$reportCards = [];


if ($role === 'teacher') {
    if (isset($_GET['student_id']) && !empty($_GET['student_id'])) {
        $student_id = $_GET['student_id'];
    } else {
        $error = "No student selected. Please select a student to view the report card.";
    }
} elseif ($role === 'student') {
  
    if (isset($_SESSION['student_id']) && !empty($_SESSION['student_id'])) {
        $student_id = $_SESSION['student_id'];
    } else {
        $stmt = $pdo->prepare("SELECT student_id FROM students WHERE user_id = ? LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $row = $stmt->fetch();
        if ($row) {
            $student_id = $row['student_id'];
            $_SESSION['student_id'] = $student_id;
        } else {
            $error = "Student record not found.";
        }
    }
} elseif ($role === 'parent') {

    if (isset($_SESSION['student_id']) && !empty($_SESSION['student_id'])) {
        $student_id = $_SESSION['student_id'];
    } else {
        $error = "No student is linked with your account. Please contact the school.";
    }
}


if (empty($error) && !empty($student_id)) {

    $stmtStudent = $pdo->prepare("SELECT student_id, student_name FROM students WHERE student_id = ?");
    $stmtStudent->execute([$student_id]);
    $student = $stmtStudent->fetch();

    if (!$student) {
        $error = "Student record not found.";
    } else {
        
        $stmtReport = $pdo->prepare("SELECT subject, grade, remarks FROM report_cards WHERE student_id = ?");
        $stmtReport->execute([$student_id]);
        $reportCards = $stmtReport->fetchAll();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Report Card</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        /* Global styles with a soft gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e0eafc);
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
            font-size: 1.1rem;
            color: #007BFF;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }
        .subheading {
            text-align: center;
            color: #555;
            margin-bottom: 20px;
        }
        .error {
            text-align: center;
            color: red;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        .message {
            text-align: center;
            color: green;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background: #007BFF;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        td {
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2><i class="fas fa-file-alt"></i> Report Card</h2>
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if (empty($error) && !empty($student)): ?>
            <div class="subheading">
                Report Card for <strong><?php echo htmlspecialchars($student['student_name']); ?></strong> (ID: <?php echo htmlspecialchars($student['student_id']); ?>)
            </div>
            <?php if (count($reportCards) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Grade</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reportCards as $entry): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($entry['subject']); ?></td>
                                <td><?php echo htmlspecialchars($entry['grade']); ?></td>
                                <td><?php echo htmlspecialchars($entry['remarks']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="message">No report card records found.</div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>
