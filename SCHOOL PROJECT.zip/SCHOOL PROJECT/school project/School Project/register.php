<?php
require 'config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $role     = $_POST['role'];
    $name     = trim($_POST['name']);
    
    
    if ($role == 'admin') {
        $admin_secret = trim($_POST['admin_secret']);
        if ($admin_secret !== ADMIN_SECRET_CODE) {
            $message = "Invalid admin secret code!";
        }
    }
    
    if ($message == '') {
     
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        try {
            $stmt->execute([$username, $email, $hashedPassword, $role]);
            $userId = $pdo->lastInsertId();

        
            if ($role == 'student') {
                $stmt2 = $pdo->prepare("INSERT INTO students (user_id, student_name) VALUES (?, ?)");
                $stmt2->execute([$userId, $name]);
            }
            elseif ($role == 'teacher') {
                $stmt2 = $pdo->prepare("INSERT INTO teachers (user_id, teacher_name) VALUES (?, ?)");
                $stmt2->execute([$userId, $name]);
            }
            elseif ($role == 'parent') {

                $linked_student = isset($_POST['linked_student']) ? trim($_POST['linked_student']) : '';
                if ($linked_student == '') {
                    $message = "Parents must be linked to a valid student ID.";
                } else {
                    $stmt2 = $pdo->prepare("INSERT INTO parents (user_id, parent_name, student_id) VALUES (?, ?, ?)");
                    $stmt2->execute([$userId, $name, $linked_student]);
                }
            }
            
            if ($message == '') {
                $message = "Registration successful! <a href='index.php'>Login here</a>";
            }
        } catch (PDOException $e) {
            $message = "Error during registration: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Maluti School Management - Register</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        h2 i {
            margin-right: 8px;
            color: #28a745;
        }
        .message {
            text-align: center;
            color: red;
            margin-bottom: 10px;
        }
        .input-group {
            position: relative;
            margin-bottom: 15px;
        }
        .input-group i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .input-group input, .input-group select {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid #ccc;
            border-radius: 4px;
            transition: border-color 0.3s ease-in-out;
        }
        .input-group input:hover, .input-group select:hover,
        .input-group input:focus, .input-group select:focus {
            border-color: #007BFF;
            outline: none;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background: #28a745;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        input[type="submit"]:hover {
            background: #218838;
        }
        p {
            text-align: center;
            margin-top: 15px;
        }
        p a {
            text-decoration: none;
            color: #007BFF;
            transition: color 0.3s ease;
        }
        p a:hover {
            color: #0056b3;
        }
        /* Hide fields by default */
        .hidden {
            display: none;
        }
    </style>
    <script>
        function toggleFields(){
            var role = document.getElementById('role').value;
            var adminSecretField = document.getElementById('adminSecretField');
            var linkedStudentField = document.getElementById('linkedStudentField');
            
            if(role === 'admin'){
                adminSecretField.style.display = 'block';
            } else {
                adminSecretField.style.display = 'none';
            }
            
            if(role === 'parent'){
                linkedStudentField.style.display = 'block';
            } else {
                linkedStudentField.style.display = 'none';
            }
        }
    </script>
</head>
<body>
<div class="container">
    <h2><i class="fas fa-user-plus"></i> Register</h2>
    <?php if ($message != '') { echo "<div class='message'>$message</div>"; } ?>
    <form method="POST" action="">
        <div class="input-group">
            <i class="fas fa-user"></i>
            <input type="text" name="name" placeholder="Full Name" required />
        </div>
        <div class="input-group">
            <i class="fas fa-user-circle"></i>
            <input type="text" name="username" placeholder="Username" required />
        </div>
        <div class="input-group">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" placeholder="Email" required />
        </div>
        <div class="input-group">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required />
        </div>
        
        <div class="input-group">
            <i class="fas fa-users"></i>
            <select name="role" id="role" onchange="toggleFields()" required>
                <option value="">Select Role</option>
                <option value="admin">Admin</option>
                <option value="teacher">Teacher</option>
                <option value="student">Student</option>
                <option value="parent">Parent</option>
            </select>
        </div>
        
     
        <div class="input-group hidden" id="adminSecretField">
            <i class="fas fa-key"></i>
            <input type="text" name="admin_secret" placeholder="Enter Admin Secret Code" />
        </div>
        
       
        <div class="input-group hidden" id="linkedStudentField">
            <i class="fas fa-link"></i>
            <input type="text" name="linked_student" placeholder="Enter Student ID to link" />
        </div>
        
        <input type="submit" value="Register" />
    </form>
    <p>Already registered? <a href="index.php"><i class="fas fa-sign-in-alt"></i> Login here</a></p>
</div>
</body>
</html>
