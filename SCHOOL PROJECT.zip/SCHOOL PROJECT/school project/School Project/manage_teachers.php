<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}

$message = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['update'])) {
        $teacher_id = $_POST['teacher_id'];
        $subject = $_POST['subject'];
        
        $new_assigned_class = ($_POST['assigned_class'] == 'none') ? NULL : $_POST['assigned_class'];
        
        
        $stmtCurrent = $pdo->prepare("SELECT assigned_class FROM teachers WHERE teacher_id = ?");
        $stmtCurrent->execute([$teacher_id]);
        $current_class = $stmtCurrent->fetchColumn();
        
       
        $stmt = $pdo->prepare("UPDATE teachers SET subject = ?, assigned_class = ? WHERE teacher_id = ?");
        $stmt->execute([$subject, $new_assigned_class, $teacher_id]);
        $message = "Teacher profile updated successfully!";
        
       
        if ($current_class && ($current_class != $new_assigned_class)) {
            $stmtClear = $pdo->prepare("UPDATE classes SET teacher_id = NULL WHERE class_id = ?");
            $stmtClear->execute([$current_class]);
        }
        
        if ($new_assigned_class !== NULL) {
            $stmtClass = $pdo->prepare("UPDATE classes SET teacher_id = ? WHERE class_id = ?");
            $stmtClass->execute([$teacher_id, $new_assigned_class]);
        }
    }
    
    
    if (isset($_POST['delete'])) {
        $teacher_id = $_POST['teacher_id'];
        
        $stmtGetClass = $pdo->prepare("SELECT assigned_class FROM teachers WHERE teacher_id = ?");
        $stmtGetClass->execute([$teacher_id]);
        $assigned_class = $stmtGetClass->fetchColumn();
        
       
        if ($assigned_class) {
            $stmtClear = $pdo->prepare("UPDATE classes SET teacher_id = NULL WHERE class_id = ?");
            $stmtClear->execute([$assigned_class]);
        }
        
        $stmtDelete = $pdo->prepare("DELETE FROM teachers WHERE teacher_id = ?");
        $stmtDelete->execute([$teacher_id]);
        $message = "Teacher profile removed successfully!";
    }
}


$stmt = $pdo->query("SELECT * FROM teachers");
$teachers = $stmt->fetchAll();


$classStmt = $pdo->query("SELECT * FROM classes ORDER BY class_name");
$classes = $classStmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Teachers - Admin</title>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"/>
    <style>
        /* Global styling with a light gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fafafa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main container styling */
        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        /* Back arrow link */
        .back-link {
            text-decoration: none;
            font-size: 1.1rem;
            color: #007BFF;
            display: inline-flex;
            align-items: center;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        /* Heading styles */
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        h2 i {
            color: #007BFF;
            margin-right: 10px;
        }
        /* Message styling */
        .message {
            text-align: center;
            font-size: 1.1rem;
            color: green;
            margin-bottom: 20px;
        }
        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            padding: 10px 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #007BFF;
            color: #fff;
        }
        /* Input and select styling for inline update form */
        input[type="text"], select {
            width: 90%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        /* Button styling with hover effects */
        input[type="submit"] {
            padding: 6px 12px;
            background: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            margin: 2px;
        }
        input[type="submit"]:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        .delete-btn {
            background: #dc3545;
        }
        .delete-btn:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        <h2><i class="fas fa-chalkboard-teacher"></i> Manage Teachers</h2>
        <?php if ($message != ''): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        
        <table>
            <tr>
                <th>ID</th>
                <th>Teacher Name</th>
                <th>Subject</th>
                <th>Assigned Class</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($teachers as $teacher): ?>
            <tr>
                <form method="POST" action="">
                    <td>
                        <?php echo $teacher['teacher_id']; ?>
                        <input type="hidden" name="teacher_id" value="<?php echo $teacher['teacher_id']; ?>">
                    </td>
                    <td><?php echo htmlspecialchars($teacher['teacher_name']); ?></td>
                    <td>
                        <input type="text" name="subject" value="<?php echo htmlspecialchars($teacher['subject']); ?>" placeholder="Enter Subject">
                    </td>
                    <td>
                        
                        <select name="assigned_class">
                            <option value="none"<?php echo (is_null($teacher['assigned_class'])) ? " selected" : ""; ?>>None</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" <?php echo ($teacher['assigned_class'] == $class['class_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <input type="submit" name="update" value="Update">
                        <input type="submit" name="delete" value="Delete" class="delete-btn">
                    </td>
                </form>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
