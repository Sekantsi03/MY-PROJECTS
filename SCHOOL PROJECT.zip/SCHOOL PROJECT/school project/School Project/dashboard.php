<?php
require 'config.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['username'];
$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard - <?php echo ucfirst($role); ?></title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"/>
    <style>
        /* Body styles with a soft gradient background */
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main dashboard container with fade-in animation */
        .dashboard-container {
            width: 600px;
            margin: 50px auto;
            padding: 30px 20px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.15);
            text-align: center;
            animation: fadeIn 1s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        /* Heading styling with icons */
        h1 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 10px;
        }
        h1 i {
            color: #28a745;
            margin-right: 10px;
        }
        h3 {
            font-size: 1.5rem;
            color: #555;
            margin-bottom: 20px;
        }
        h3 i {
            color: #007BFF;
            margin-right: 5px;
        }
        /* Logout button styling */
        .logout {
            margin-bottom: 20px;
        }
        .logout a {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            background: #dc3545;
            color: #fff;
            padding: 10px 20px;
            border-radius: 30px;
            font-size: 1rem;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        .logout a i {
            margin-right: 8px;
        }
        .logout a:hover {
            background: #c82333;
            transform: translateY(-2px);
        }
        /* Container for dashboard options */
        .options-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
        }
        /* Pill-shaped button style for each option */
        .option {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 220px;
            padding: 15px 25px;
            text-decoration: none;
            border-radius: 30px;
            font-size: 1rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            color: #fff;
        }
        .option i {
            margin-right: 8px;
        }
        .option:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        /* Role-specific background colors */
        .admin { background: #007BFF; }
        .teacher { background: #28a745; }
        .student { background: #ffc107; color: #333; }
        .parent { background: #17a2b8; }
    </style>
</head>
<body>
    <div class="dashboard-container">
       
        <h1><i class="fas fa-user-circle"></i> Welcome, <?php echo $username; ?>!</h1>
        <h3><i class="fas fa-info-circle"></i> Logged in as <?php echo ucfirst($role); ?></h3>
        
        
        <div class="logout">
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        
        
        <div class="options-container">
            <?php if ($role == 'admin'): ?>
                
                <a href="manage_students.php" class="option admin">
                    <i class="fas fa-users"></i> Manage Students
                </a>
                <a href="manage_teachers.php" class="option admin">
                    <i class="fas fa-chalkboard-teacher"></i> Manage Teachers
                </a>
                <a href="fee_management.php" class="option admin">
                    <i class="fas fa-money-bill-wave"></i> Fee Management
                </a>
                <a href="notifications.php" class="option admin">
                    <i class="fas fa-bell"></i> Send Notifications
                </a>
                <a href="reports.php" class="option admin">
                    <i class="fas fa-chart-line"></i> Generate Reports
                </a>
            <?php elseif ($role == 'teacher'): ?>
                
                <a href="attendance.php" class="option teacher">
                    <i class="fas fa-calendar-check"></i> Mark Attendance
                </a>
                <a href="enter_grades.php" class="option teacher">
                    <i class="fas fa-pen"></i> Enter Grades
                </a>
                <a href="generate_reportcard.php" class="option teacher">
                    <i class="fas fa-file-export"></i> Generate Report Card
                </a>
            <?php elseif ($role == 'student'): ?>
               
                <a href="view_attendance.php" class="option student">
                    <i class="fas fa-eye"></i> View Attendance
                </a>
                <a href="view_reportcard.php" class="option student">
                    <i class="fas fa-file-alt"></i> View Report Card
                </a>
            <?php elseif ($role == 'parent'): ?>
                
                <a href="view_attendance_parent.php" class="option parent">
                    <i class="fas fa-user-graduate"></i> View Child Attendance
                </a>
                <a href="view_child_report.php" class="option parent">
                    <i class="fas fa-file-alt"></i> View Child Report Card
                </a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
