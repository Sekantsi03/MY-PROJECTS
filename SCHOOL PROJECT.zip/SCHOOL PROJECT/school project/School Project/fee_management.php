<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    if (isset($_POST['submit_payment'])) {
        $student_id = trim($_POST['student_id']);
        $amount = trim($_POST['amount']);
        $due_date = trim($_POST['due_date']);
        
      
        $invoice_number = "INV" . rand(1000, 9999);
        
        $stmt = $pdo->prepare("INSERT INTO fee_payments (student_id, amount, due_date, invoice_number) VALUES (?, ?, ?, ?)");
        try {
            $stmt->execute([$student_id, $amount, $due_date, $invoice_number]);
            $message = "Fee payment record added successfully!";
        } catch (PDOException $e) {
            $message = "Error adding fee payment: " . $e->getMessage();
        }
    }
    
 
    if (isset($_POST['mark_paid'])) {
        $fee_id = $_POST['fee_id'];
        $stmtPaid = $pdo->prepare("UPDATE fee_payments SET paid_date = CURDATE() WHERE fee_id = ?");
        try {
            $stmtPaid->execute([$fee_id]);
            $message = "Fee marked as paid!";
        } catch (PDOException $e) {
            $message = "Error marking fee as paid: " . $e->getMessage();
        }
    }
}

$stmt2 = $pdo->query("SELECT * FROM fee_payments ORDER BY fee_id DESC");
$fees = $stmt2->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Fees Management - Admin</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        /* Global body styling with a soft gradient background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fafafa, #e0eafc);
            margin: 0;
            padding: 0;
        }
        /* Main container styling */
        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        /* Back Arrow Link styling */
        .back-link {
            text-decoration: none;
            font-size: 1.1rem;
            color: #007BFF;
            display: inline-flex;
            align-items: center;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        /* Heading styling with icon */
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        h2 i {
            color: #007BFF;
            margin-right: 10px;
        }
        /* Message styling */
        .message {
            text-align: center;
            font-size: 1.1rem;
            color: green;
            margin-bottom: 20px;
        }
        /* Fee Payment Form styling */
        form.fee-form {
            max-width: 400px;
            margin: 0 auto 30px auto;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #f9f9f9;
        }
        .fee-form h3 {
            text-align: center;
            margin-bottom: 15px;
            color: #333;
        }
        .fee-form .input-group {
            margin-bottom: 15px;
            position: relative;
        }
        .fee-form .input-group i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .fee-form .input-group input {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s ease;
        }
        .fee-form .input-group input:hover,
        .fee-form .input-group input:focus {
            border-color: #007BFF;
            outline: none;
        }
        .fee-form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        .fee-form input[type="submit"]:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }
        /* Fee Payment Records Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            padding: 10px 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        table th {
            background-color: #007BFF;
            color: #fff;
        }
        /* Payment Status styling */
        .paid {
            color: green;
            font-weight: bold;
        }
        .not-paid {
            color: red;
            font-weight: bold;
        }
        /* Mark as Paid button in table */
        .mark-btn {
            padding: 4px 8px;
            background: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        .mark-btn:hover {
            background: #218838;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
    
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        
        <h2><i class="fas fa-money-check-alt"></i> Fees Management</h2>
        
        <?php if ($message != ''): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        
        <form method="POST" action="" class="fee-form">
            <h3><i class="fas fa-plus-circle"></i> Add Fee Payment</h3>
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="student_id" placeholder="Enter Student ID" required>
            </div>
            <div class="input-group">
                <i class="fas fa-dollar-sign"></i>
                <input type="text" name="amount" placeholder="Enter Amount" required>
            </div>
            <div class="input-group">
                <i class="fas fa-calendar-alt"></i>
                <input type="date" name="due_date" required>
            </div>
            <input type="submit" name="submit_payment" value="Submit Payment">
        </form>
        
        <table>
            <tr>
                <th>Fee ID</th>
                <th>Student ID</th>
                <th>Amount</th>
                <th>Due Date</th>
                <th>Invoice Number</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($fees as $fee): ?>
                <tr>
                    <td><?php echo $fee['fee_id']; ?></td>
                    <td><?php echo htmlspecialchars($fee['student_id']); ?></td>
                    <td><?php echo htmlspecialchars($fee['amount']); ?></td>
                    <td><?php echo htmlspecialchars($fee['due_date']); ?></td>
                    <td><?php echo htmlspecialchars($fee['invoice_number']); ?></td>
                    <td>
                        <?php if (is_null($fee['paid_date'])): ?>
                            <span class="not-paid">Not Paid</span>
                        <?php else: ?>
                            <span class="paid">Paid</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (is_null($fee['paid_date'])): ?>
                            <form method="POST" action="">
                                <input type="hidden" name="fee_id" value="<?php echo $fee['fee_id']; ?>">
                                <input type="submit" name="mark_paid" class="mark-btn" value="Mark as Paid">
                            </form>
                        <?php else: ?>
                            <em>-</em>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
