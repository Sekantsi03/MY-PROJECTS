<?php
require 'config.php';


if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['teacher', 'student', 'parent'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'];
$student_id = null;
$error = "";
$message = "";

if ($role === 'teacher') {
    if (isset($_GET['student_id']) && !empty($_GET['student_id'])) {
        $student_id = $_GET['student_id'];
    } else {
       
        $teacherUserId = $_SESSION['user_id'];
        $stmtTeacher = $pdo->prepare("SELECT assigned_class FROM teachers WHERE user_id = ?");
        $stmtTeacher->execute([$teacherUserId]);
        $teacher = $stmtTeacher->fetch();
        if (!$teacher || empty($teacher['assigned_class'])) {
            $error = "No class assigned to you. Please contact the administrator.";
        } else {
            $classID = $teacher['assigned_class'];
          
            $stmtStudents = $pdo->prepare("SELECT student_id, student_name FROM students WHERE class_id = ?");
            $stmtStudents->execute([$classID]);
            $studentsList = $stmtStudents->fetchAll();
        }
    }
} elseif ($role === 'student') {
    if (isset($_SESSION['student_id'])) {
        $student_id = $_SESSION['student_id'];
    } else {
        $error = "Student record not found.";
    }
} elseif ($role === 'parent') {
   
    if (isset($_SESSION['student_id'])) {
        $student_id = $_SESSION['student_id'];
    } else {
        $error = "No student is linked with your account. Please contact the school.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Generate Report Card</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        /* Global styles */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e0eafc);
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
            font-size: 1.1rem;
            color: #007BFF;
            transition: transform 0.3s ease;
        }
        .back-link i {
            margin-right: 5px;
        }
        .back-link:hover {
            transform: translateX(-5px);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        h3 {
            text-align: center;
            color: #555;
            margin-top: 10px;
        }
        .error {
            text-align: center;
            color: red;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        .message {
            text-align: center;
            color: green;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th {
            background: #007BFF;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        td {
            padding: 10px;
            text-align: center;
        }
        .student-list {
            margin: 20px 0;
        }
        .student-list li {
            list-style: none;
            margin-bottom: 10px;
        }
        .student-list a {
            text-decoration: none;
            color: #007BFF;
            font-size: 1rem;
            transition: color 0.3s;
        }
        .student-list a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
      
        <a href="dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        <h2><i class="fas fa-file-alt"></i> Report Card</h2>
        
        <?php
        if (!empty($error)) {
            echo "<div class='error'>" . htmlspecialchars($error) . "</div>";
        }
        if (!empty($message)) {
            echo "<div class='message'>" . htmlspecialchars($message) . "</div>";
        }
        ?>
        
        <?php
     
        if ($role === 'teacher' && !$student_id && empty($error)) {
            if (isset($studentsList) && count($studentsList) > 0) {
                echo "<h3>Select a Student:</h3>";
                echo "<ul class='student-list'>";
                foreach ($studentsList as $stud) {
                    echo "<li><a href='generate_reportcard.php?student_id=" . $stud['student_id'] . "'>" 
                         . htmlspecialchars($stud['student_name']) 
                         . " (ID: " . htmlspecialchars($stud['student_id']) . ")</a></li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No students found in your assigned class.</p>";
            }
        }
        ?>
        
        <?php
        
        if (isset($student_id) && !empty($student_id)) {
           
            $stmtStudent = $pdo->prepare("SELECT student_id, student_name FROM students WHERE student_id = ?");
            $stmtStudent->execute([$student_id]);
            $student = $stmtStudent->fetch();
            
            if (!$student) {
                echo "<div class='error'>Student record not found.</div>";
            } else {
                echo "<h3>Report Card for " . htmlspecialchars($student['student_name']) . " (ID: " . htmlspecialchars($student['student_id']) . ")</h3>";
                
                
                $stmtReports = $pdo->prepare("SELECT subject, grade, remarks FROM report_cards WHERE student_id = ?");
                $stmtReports->execute([$student_id]);
                $reports = $stmtReports->fetchAll();
                
                if (count($reports) > 0) {
                    echo "<table>";
                    echo "<thead>";
                    echo "<tr><th>Subject</th><th>Grade</th><th>Remarks</th></tr>";
                    echo "</thead><tbody>";
                    foreach ($reports as $report) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($report['subject']) . "</td>";
                        echo "<td>" . htmlspecialchars($report['grade']) . "</td>";
                        echo "<td>" . htmlspecialchars($report['remarks']) . "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody></table>";
                } else {
                    echo "<p>No report card records found for this student.</p>";
                }
            }
        }
        ?>
    </div>
</body>
</html>
