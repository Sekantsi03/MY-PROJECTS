-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2025 at 04:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2230476`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `id` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `internshipId` int(11) NOT NULL,
  `status` enum('Pending','Accepted','Rejected') DEFAULT 'Pending',
  `cvPath` varchar(255) NOT NULL,
  `transcriptPath` varchar(255) NOT NULL,
  `applicationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `studentId`, `internshipId`, `status`, `cvPath`, `transcriptPath`, `applicationDate`) VALUES
(4, 6, 2, 'Accepted', 'C7-DSA-11 INT 4.pdf', 'C7-ADJ-11 END  Exam Question Paper.pdf', '2025-04-26 13:53:42'),
(5, 6, 3, 'Accepted', 'WDD-Lecture-2.pdf', 'C7-JAV-11 End QP (1).pdf', '2025-04-26 14:10:42'),
(7, 6, 6, 'Rejected', 'filestreams.pdf', 'pdfcoffee.com_forex-ict-amp-mmm-notespdf-5-pdf-free.pdf', '2025-04-28 19:28:24'),
(9, 6, 5, 'Rejected', 'Boom-And-Crash-Forex-Notes.pdf', 'forex secret indicator ( PDFDrive ).pdf', '2025-04-28 19:31:58'),
(10, 6, 8, 'Pending', 'Volatility75-Strategy.pdf', 'The ART of Trading_ Combining the Science of Technical Analysis with the Art of Reality-Based Trading ( PDFDrive ).pdf', '2025-04-29 08:23:54');

-- --------------------------------------------------------

--
-- Table structure for table `internships`
--

CREATE TABLE `internships` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `companyName` varchar(255) NOT NULL,
  `location` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `postedDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `postedBy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `internships`
--

INSERT INTO `internships` (`id`, `title`, `companyName`, `location`, `description`, `postedDate`, `postedBy`) VALUES
(2, 'Database manager', 'SData', 'sehlabeng', 'manage database', '2025-04-26 13:52:20', 2),
(3, 'Culinary', 'mosh', 'thetsane', 'culinary arts', '2025-04-26 14:09:42', 2),
(5, 'marketing intern', 'cbs', 'maseru', 'manage social media campaigns', '2025-04-28 19:22:30', 2),
(6, 'HR intern', 'letshego', 'hlotse', 'support recruitment', '2025-04-28 19:25:34', 2),
(8, 'networking intern', 'comnet', 'maseru', 'manage networks', '2025-04-29 08:14:10', 2),
(9, 'audit intern', 'cas', 'maseru', 'manage audits', '2025-04-30 13:09:20', 2),
(10, 'audit intern', 'cas', 'maseru', 'manage audits', '2025-04-30 13:11:30', 2),
(14, 'sdd', 'sddffff', 'ffffff', 'dfdv', '2025-04-30 13:37:07', 2),
(15, 'jkkoppk', 'ookkl,k;l', 'kmjkk', 'jujko', '2025-04-30 13:45:16', 2),
(16, 'ggbng', 'dgdNC', 'cv', 'fjmfzm', '2025-04-30 13:48:22', 2);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `recipientId` int(11) NOT NULL,
  `notificationType` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `internshipId` int(11) NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` between 1 and 5),
  `comments` text DEFAULT NULL,
  `employerReply` text DEFAULT NULL,
  `reviewDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `studentId`, `internshipId`, `rating`, `comments`, `employerReply`, `reviewDate`) VALUES
(1, 6, 2, 3, 'not good', NULL, '2025-04-26 15:00:51'),
(2, 6, 2, 3, 'not good', NULL, '2025-04-26 15:00:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Student','Employer','Admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `active`) VALUES
(2, 'sekantsi', 'thabosekantsi93@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Employer', '2025-04-24 17:05:53', 1),
(6, 'thabo', 'thabosekantsi03@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Student', '2025-04-26 12:56:29', 1),
(7, 'admin', 'thabo@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Admin', '2025-04-27 04:49:33', 1),
(8, 'meech', 'thabosekantsi@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Student', '2025-04-30 21:51:18', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_student` (`studentId`),
  ADD KEY `fk_internship` (`internshipId`);

--
-- Indexes for table `internships`
--
ALTER TABLE `internships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_postedBy` (`postedBy`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_notification_user` (`recipientId`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_review_student` (`studentId`),
  ADD KEY `fk_review_internship` (`internshipId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `internships`
--
ALTER TABLE `internships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `applications`
--
ALTER TABLE `applications`
  ADD CONSTRAINT `fk_internship` FOREIGN KEY (`internshipId`) REFERENCES `internships` (`id`),
  ADD CONSTRAINT `fk_student` FOREIGN KEY (`studentId`) REFERENCES `users` (`id`);

--
-- Constraints for table `internships`
--
ALTER TABLE `internships`
  ADD CONSTRAINT `fk_postedBy` FOREIGN KEY (`postedBy`) REFERENCES `users` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notification_user` FOREIGN KEY (`recipientId`) REFERENCES `users` (`id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `fk_review_internship` FOREIGN KEY (`internshipId`) REFERENCES `internships` (`id`),
  ADD CONSTRAINT `fk_review_student` FOREIGN KEY (`studentId`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
