/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Role {
    private String role;  // Represents the role: "student", "employer", or "admin"

    // Default constructor
    public Role() {}

    // Constructor with role
    public Role(String role) {
        this.role = role;
    }

    // Getter method to get the role
    public String getRole() {
        return role;
    }

    // Setter method to set the role
    public void setRole(String role) {
        this.role = role;
    }

    // Method to check if the current role matches the given role
    public boolean hasRole(String roleToCheck) {
        // Check if the role is not null and matches the given role (case-insensitive)
        return role != null && role.equalsIgnoreCase(roleToCheck);
    }

    // Helper method to check if the role is "student"
    public boolean isStudent() {
        return hasRole("student");
    }

    // Helper method to check if the role is "employer"
    public boolean isEmployer() {
        return hasRole("employer");
    }

    // Helper method to check if the role is "admin"
    public boolean isAdmin() {
        return hasRole("admin");
    }
}
