/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import jakarta.servlet.http.HttpSession;

public class SessionUtil {

    // Method to check if a user is logged in
    public static boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("user") != null;
    }

    // Method to log out a user
    public static void logOut(HttpSession session) {
        session.invalidate();
    }

    // Method to get user role from session
    public static String getUserRole(HttpSession session) {
        if (session.getAttribute("user") != null) {
            return session.getAttribute("user").toString();
        }
        return null;
    }

    // Method to set user in session
    public static void setUserInSession(HttpSession session, Object user) {
        session.setAttribute("user", user);
    }
}
