package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.Application;
import model.User;
import util.DBConnection;

import java.io.IOException;
import java.sql.*;


public class ApplicationStatusServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        User user = (User) session.getAttribute("user");

        ApplicationStatus status = null;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT i.title, i.company_name, a.status, a.application_date " +
                         "FROM applications a " +
                         "JOIN internships i ON a.internship_id = i.id " +
                         "WHERE a.student_id = ? " +
                         "ORDER BY a.application_date DESC LIMIT 1";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, user.getId());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                status = new ApplicationStatus();
                status.setInternshipTitle(rs.getString("title"));
                status.setCompanyName(rs.getString("company_name"));
                status.setStatus(rs.getString("status"));
                status.setApplicationDate(rs.getDate("application_date"));
            }

            request.setAttribute("status", status);
            request.getRequestDispatcher("applicationstatus.jsp").forward(request, response);

        } catch (SQLException e) {
            response.getWriter().println("Database error while fetching application status.");
        }
    }
}
