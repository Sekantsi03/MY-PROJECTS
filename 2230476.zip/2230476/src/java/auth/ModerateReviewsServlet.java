package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.Review;
import util.DBConnection;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ModerateReviewsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Review> reviews = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT r.id, r.content, u.full_name FROM reviews r JOIN users u ON r.user_id = u.id");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Review review = new Review();
                review.setId(rs.getInt("id"));
                review.setContent(rs.getString("content"));
                review.setUserName(rs.getString("full_name"));
                reviews.add(review);
            }

        } catch (SQLException e) {
            request.setAttribute("error", "Database error while loading reviews.");
        }

        request.setAttribute("reviews", reviews);
        request.getRequestDispatcher("moderatereviews.jsp").forward(request, response);
    }
}
