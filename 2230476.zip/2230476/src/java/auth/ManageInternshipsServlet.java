package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import dao.InternshipDAO;
import model.Internship;

import java.io.IOException;
import java.util.List;


public class ManageInternshipsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        InternshipDAO internshipDAO = new InternshipDAO();
        List<Internship> internships = internshipDAO.getAllInternships();

        request.setAttribute("internships", internships);
        request.getRequestDispatcher("manageinternships.jsp").forward(request, response);
    }
}
