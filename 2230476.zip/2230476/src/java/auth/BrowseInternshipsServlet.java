/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package auth;


import util.DBConnection;
import model.Internship;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BrowseInternshipsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int page = 1;
        int recordsPerPage = 5;
        if (request.getParameter("page") != null)
            page = Integer.parseInt(request.getParameter("page"));

        List<Internship> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM internships LIMIT ?, ?");
            ps.setInt(1, (page - 1) * recordsPerPage);
            ps.setInt(2, recordsPerPage);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Internship internship = new Internship();
                internship.setId(rs.getInt("id"));
                internship.setTitle(rs.getString("title"));
                internship.setCompanyName(rs.getString("company_name"));
                internship.setLocation(rs.getString("location"));
                internship.setPostedDate(rs.getString("posted_date"));
                internship.setDescription(rs.getString("description"));
                list.add(internship);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        request.setAttribute("internshipList", list);
        request.setAttribute("currentPage", page);
        request.getRequestDispatcher("browse_internships.jsp").forward(request, response);
    }
}