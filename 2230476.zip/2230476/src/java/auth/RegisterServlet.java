package auth;

import util.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;

public class RegisterServlet extends HttpServlet {

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashed = md.digest(password.getBytes("UTF-8"));

            StringBuilder sb = new StringBuilder();
            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();

        } catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {
            return null;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String firstName = request.getParameter("firstName");
        String lastName  = request.getParameter("lastName");
        String email     = request.getParameter("email");
        String password  = request.getParameter("password");
        String role      = request.getParameter("role");

        String fullName = firstName + " " + lastName;

        if (firstName == null || lastName == null || email == null || password == null || role == null) {
            response.sendRedirect("register.jsp?error=All+fields+are+required");
            return;
        }

        String hashedPassword = hashPassword(password);

        if (hashedPassword == null) {
            response.sendRedirect("register.jsp?error=Password+hashing+failed");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            // Check if email already exists
            String checkQuery = "SELECT id FROM users WHERE email = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
                checkStmt.setString(1, email);
                ResultSet rs = checkStmt.executeQuery();

                if (rs.next()) {
                    response.sendRedirect("register.jsp?error=Email+already+exists");
                    return;
                }
            }

            String query = "INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, fullName);
                ps.setString(2, email);
                ps.setString(3, hashedPassword);
                ps.setString(4, role);

                int result = ps.executeUpdate();

                if (result > 0) {
                    response.sendRedirect("login.jsp?message=Registration+successful!+Please+login.");
                } else {
                    response.sendRedirect("register.jsp?error=Registration+failed");
                }
            }

        } catch (SQLException e) {
            response.sendRedirect("register.jsp?error=Database+error");
        }
    }
}
