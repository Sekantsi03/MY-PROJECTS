package auth;

import dao.ReviewDAO;
import model.Review;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;


public class ReplyReviewServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get the review ID and the employer's reply from the request
        String reviewIdParam = request.getParameter("reviewId");
        String reply = request.getParameter("reply");

        if (reviewIdParam != null && !reviewIdParam.isEmpty() && reply != null && !reply.trim().isEmpty()) {
            try {
                int reviewId = Integer.parseInt(reviewIdParam);

                // Fetch the review from the database
                Review review = ReviewDAO.getReviewById(reviewId);
                
                if (review != null) {
                    // Set the employer's reply to the review
                    review.setEmployerReply(reply);

                    // Update the review in the database
                    boolean isUpdated = ReviewDAO.updateReviewReply(review);

                    if (isUpdated) {
                        // Send an email notification to the student about the employer's reply
                        String studentEmail = review.getStudentEmail();
                        String subject = "Response to Your Review for " + review.getInternshipTitle();
                        String body = "Dear Student,\n\nThe employer has replied to your review: \n\n" + reply;
                        boolean emailSent = EmailUtility.sendEmail(studentEmail, subject, body);

                        if (emailSent) {
                            response.sendRedirect("dashboard");  // Or redirect to the page where reviews are shown
                        } else {
                            response.sendRedirect("error.jsp");  // Error sending email
                        }
                    } else {
                        response.sendRedirect("error.jsp");  // Error updating review in DB
                    }
                } else {
                    response.sendRedirect("error.jsp");  // Review not found
                }

            } catch (NumberFormatException e) {
                response.sendRedirect("error.jsp");  // Invalid review ID
            }
        } else {
            response.sendRedirect("error.jsp");  // Missing reply or review ID
        }
    }
}
