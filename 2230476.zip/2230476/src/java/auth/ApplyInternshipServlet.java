package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import model.User;
import util.DBConnection;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;

@MultipartConfig
public class ApplyInternshipServlet extends HttpServlet {
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    // session + role check
    HttpSession session = request.getSession(false);
    User user = (session == null) ? null : (User) session.getAttribute("user");
    if (user == null || !"student".equals(user.getRole())) {
      response.sendRedirect(request.getContextPath() + "/login.jsp");
      return;
    }

    int internshipId = Integer.parseInt(request.getParameter("internshipId"));
    Part cvPart      = request.getPart("cv");
    Part trPart      = request.getPart("transcript");

    // build upload folder
    String realBase = getServletContext().getRealPath("/");
    Path uploadDir  = Paths.get(realBase, "application-data", "student-files");
    Files.createDirectories(uploadDir);

    // unique filenames
    String cvName = UUID.randomUUID() + "_" +
                    Paths.get(cvPart.getSubmittedFileName()).getFileName();
    String trName = UUID.randomUUID() + "_" +
                    Paths.get(trPart.getSubmittedFileName()).getFileName();

    // copy files
    try (InputStream cvIn = cvPart.getInputStream();
         InputStream trIn = trPart.getInputStream()) {
      Files.copy(cvIn, uploadDir.resolve(cvName), StandardCopyOption.REPLACE_EXISTING);
      Files.copy(trIn, uploadDir.resolve(trName), StandardCopyOption.REPLACE_EXISTING);
    }

    // insert application
    String sql = "INSERT INTO applications "
               + "(user_id, internship_id, cv_path, transcript_path, status) "
               + "VALUES (?, ?, ?, ?, 'Pending')";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

      stmt.setInt(1, user.getId());
      stmt.setInt(2, internshipId);
      stmt.setString(3, "application-data/student-files/" + cvName);
      stmt.setString(4, "application-data/student-files/" + trName);
      stmt.executeUpdate();

      session.setAttribute("message", "Application submitted successfully!");
      response.sendRedirect(request.getContextPath() + "/internships");
      return;

    } catch (SQLException e) {
      log("Failed to submit application", e);
      request.setAttribute("error", "Failed to submit application.");
      request.getRequestDispatcher("/apply.jsp")
             .forward(request, response);
      return;
    }
  }
}

