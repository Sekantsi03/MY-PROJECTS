package auth;

import model.User;
import util.DBConnection;
import util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;


public class LoginServlet extends HttpServlet {

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashed = md.digest(password.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
            return null;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String hashedPassword = hashPassword(password);

        if (hashedPassword == null) {
            request.setAttribute("message", "Error hashing password.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, hashedPassword);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setFullName(rs.getString("full_name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));

                HttpSession session = request.getSession();
                SessionUtil.setUserInSession(session, user);

                String role = user.getRole().toLowerCase();
                String dashboardURL = "";
                switch (role) {
                    case "student" -> dashboardURL = "studentdashboard.jsp";
                    case "employer" -> dashboardURL = "employerdashboard.jsp";
                    case "admin" -> dashboardURL = "admindashboard.jsp";
                    default -> {
                        request.setAttribute("message", "Unknown user role.");
                        request.getRequestDispatcher("login.jsp").forward(request, response);
                        return;
                    }
                }

                // Redirect to the appropriate dashboard with a success message
                response.sendRedirect(dashboardURL + "?message=Login+successful");
            } else {
                request.setAttribute("message", "Invalid email or password.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            request.setAttribute("message", "Database error. Please try again.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
