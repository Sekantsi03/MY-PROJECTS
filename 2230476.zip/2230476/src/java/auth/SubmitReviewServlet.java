package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Review;
import model.User;
import util.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class SubmitReviewServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Redirect to login if not logged in or not student
        if (user == null || !"student".equals(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "login.jsp");
            return;
        }

        String internshipTitle = request.getParameter("internshipTitle");
        String reviewText = request.getParameter("review");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO reviews (student_id, internship_title, review) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, user.getId());
            stmt.setString(2, internshipTitle);
            stmt.setString(3, reviewText);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                request.setAttribute("message", "Review submitted successfully!");
            } else {
                request.setAttribute("message", "Failed to submit review.");
            }
        } catch (Exception e) {
            request.setAttribute("message", "Error: " + e.getMessage());
        }

        request.getRequestDispatcher("submitreview.jsp").forward(request, response);
    }
}
