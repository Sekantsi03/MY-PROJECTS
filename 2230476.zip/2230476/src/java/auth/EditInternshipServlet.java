
package auth;

import dao.InternshipDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.Internship;

import java.io.IOException;


public class EditInternshipServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int internshipId = Integer.parseInt(request.getParameter("id"));
            Internship internship = InternshipDAO.getInternshipById(internshipId);

            if (internship != null) {
                request.setAttribute("internship", internship);
                request.getRequestDispatcher("editinternship.jsp").forward(request, response);
            } else {
                response.sendRedirect("employerdashboard");
            }
        } catch (Exception e) {
            response.sendRedirect("employerdashboard");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            String requirements = request.getParameter("requirements");
            String location = request.getParameter("location");

            Internship internship = new Internship();
            internship.setId(id);
            internship.setTitle(title);
            internship.setDescription(description);
            internship.setRequirements(requirements);
            internship.setLocation(location);

            InternshipDAO.updateInternship(internship);
            response.sendRedirect("employerdashboard");
        } catch (Exception e) {
            request.setAttribute("error", "Failed to update internship.");
            request.getRequestDispatcher("editinternship.jsp").forward(request, response);
        }
    }
}
