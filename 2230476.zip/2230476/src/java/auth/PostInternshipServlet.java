package auth;

import util.DBConnection;
import util.SessionUtil;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PostInternshipServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Session and role check
        HttpSession session = request.getSession(false);
        if (session == null || !SessionUtil.isLoggedIn(session)) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        User employer = (User) session.getAttribute("user");
        if (employer == null || !"employer".equalsIgnoreCase(employer.getRole())) {
            response.sendRedirect(request.getContextPath() + "/unauthorized.jsp");
            return;
        }

        // Grab form fields
        String title       = request.getParameter("title");
        String description = request.getParameter("description");
        String location    = request.getParameter("location");

        // Note: no 'requirements' here
        String sql = "INSERT INTO internships "
                   + "(title, description, location, employer_id, company_name, posted_date) "
                   + "VALUES (?, ?, ?, ?, ?, CURRENT_DATE)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setString(3, location);
            stmt.setInt(4, employer.getId());
            stmt.setString(5, employer.getFullName());

            stmt.executeUpdate();

            // Success → back to employer dashboard
            response.sendRedirect(request.getContextPath() + "/employerdashboard.jsp");
        }
        catch (SQLException e) {
            log("Error posting internship", e);
            request.setAttribute("error", "Failed to post internship. Please try again.");
            request.getRequestDispatcher("/postinternship.jsp")
                   .forward(request, response);
        }
    }
}
