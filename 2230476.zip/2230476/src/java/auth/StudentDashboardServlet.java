package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;
import util.SessionUtil;

import java.io.IOException;


public class StudentDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || !SessionUtil.isLoggedIn(session)) {
            response.sendRedirect(request.getContextPath() + "/login.jsp"); // ✅ fixed missing slash
            return;
        }

        User user = (User) session.getAttribute("user");

        if (!"student".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/unauthorized.jsp"); // ✅ fixed missing slash
            return;
        }

        request.getRequestDispatcher("studentdashboard.jsp").forward(request, response);
    }
}
