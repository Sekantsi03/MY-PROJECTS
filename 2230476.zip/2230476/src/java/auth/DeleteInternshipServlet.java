package auth;

import dao.InternshipDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;


public class DeleteInternshipServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String internshipIdParam = request.getParameter("internshipId");

        if (internshipIdParam != null && !internshipIdParam.isEmpty()) {
            try {
                int internshipId = Integer.parseInt(internshipIdParam);
                boolean deleted = InternshipDAO.deleteInternship(internshipId);

                if (deleted) {
                    response.sendRedirect("dashboard"); // or wherever the updated list is shown
                } else {
                    response.sendRedirect("error.jsp"); // you can customize this
                }

            } catch (NumberFormatException e) {
                response.sendRedirect("error.jsp");
            }
        } else {
            response.sendRedirect("error.jsp");
        }
    }
}
