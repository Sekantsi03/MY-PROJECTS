/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.SessionUtil;

import java.io.IOException;


public class EmployerDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Check if user is logged in and is an employer
        if (!SessionUtil.isLoggedIn(request.getSession()) || 
            !"employer".equalsIgnoreCase(SessionUtil.getUserRole(request.getSession()))) {
            response.sendRedirect(request.getContextPath() + "login.jsp");
            return;
        }

        // Forward to the employer dashboard JSP
        request.getRequestDispatcher("employerdashboard.jsp").forward(request, response);
    }
}
