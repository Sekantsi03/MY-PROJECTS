package auth;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Internship;
import util.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ViewInternshipsServlet extends HttpServlet {
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    List<Internship> internships = new ArrayList<>();

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(
             "SELECT * FROM internships ORDER BY posted_date DESC");
         ResultSet rs = stmt.executeQuery()) {

      while (rs.next()) {
        Internship i = new Internship();
        i.setId(rs.getInt("id"));
        i.setTitle(rs.getString("title"));
        i.setCompanyName(rs.getString("company_name"));
        i.setLocation(rs.getString("location"));
        i.setPostedDate(rs.getString("posted_date"));
        i.setDescription(rs.getString("description"));
        internships.add(i);
      }

    } catch (Exception e) {
      log("Error loading internships", e);
      request.setAttribute("error", "Could not load internships at this time.");
    }

    request.setAttribute("internships", internships);

    // decide which JSP to show
    String target = request.getParameter("apply") != null
        ? "/apply.jsp"
        : "/internships.jsp";

    request.getRequestDispatcher(target)
           .forward(request, response);
  }
}
