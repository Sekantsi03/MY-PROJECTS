
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Salesperson extends javax.swing.JFrame {

    /**
     * Creates new form Salesperson
     */
    public Salesperson() {
        Connection con= null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sekantsi2230476", "root", ""); 

            System.out.println("Connection established");

        } catch (Exception e) {
            System.out.println("Connection not established");
            System.out.println(e);
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage(), 
                                          "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();

        jLabel3.setText("jLabel3");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jLabel2.setText("Report here");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sales Person");
        setBackground(java.awt.Color.lightGray);

        jLabel1.setText("Search  by ProductID");

        jButton1.setText("Search Product");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("View INFO");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Report Low Stock");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTable1.setBackground(new java.awt.Color(51, 51, 51));
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Product ID", "Product name", "Price", "category", "Quantity"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton4.setLabel("Back");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(44, 44, 44)
                        .addComponent(jButton2)
                        .addGap(45, 45, 45)
                        .addComponent(jButton4)
                        .addGap(91, 91, 91))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1)
                        .addGap(130, 130, 130))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton2)
                    .addComponent(jButton4))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        jButton4.getAccessibleContext().setAccessibleName("btnBack");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
                   // Clear any existing data in the table
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    // Clear existing rows
    model.setRowCount(0); 

    try {
        // Open database connection
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sekantsi2230476", "root", "");

        // Create SQL query to get all products
        String sql = "SELECT * FROM products";
        PreparedStatement statement = con.prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery();

        // Iterate through the result set and add rows to the model
        while (resultSet.next()) {
            // Retrieve data from the ResultSet
            int ProdID = resultSet.getInt("ProdID");
            String name = resultSet.getString("Name"); 
            double price = resultSet.getDouble("Price"); 
            String category = resultSet.getString("Category"); 
            int quantity = resultSet.getInt("Quantity"); 

            // Add a new row to the model in the order: Name, Price, Category, Quantity
            model.addRow(new Object[]{ProdID,name, price, category, quantity});
        }

        // Close the ResultSet and Statement
        resultSet.close();
        statement.close();
        // Close the connection to the database
        con.close();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "SQL Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } catch (ClassNotFoundException e) {
        JOptionPane.showMessageDialog(this, "Database Driver Not Found: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
                       // // Clear any existing data in the table
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    // Clear existing rows
    model.setRowCount(0); 
    
    // Get the search term from the text field
    String searchTerm = jTextField1.getText().trim();

    // Check if the search term is empty
    if (searchTerm.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a product name to search.", "Warning", JOptionPane.WARNING_MESSAGE);
        return; // Exit the method if the searchTerm is empty
    }

    try {
        // Open database connection
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sekantsi2230476", "root", "");

        // Create SQL query to search for the product
        String sql = "SELECT * FROM products WHERE ProdID LIKE ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setString(1, "%" + searchTerm + "%"); // Use LIKE for partial matching
        ResultSet resultSet = statement.executeQuery();

        // Iterate through the result set and add rows to the model
        while (resultSet.next()) {
            int prodid = resultSet.getInt("ProdID");
            String name = resultSet.getString("Name");
            double price = resultSet.getDouble("Price");
            String category = resultSet.getString("Category");
            int quantity = resultSet.getInt("Quantity");

            // Add a new row to the model
            model.addRow(new Object[]{prodid,name, price, category, quantity});
        }

        // Close the ResultSet and Statement
        resultSet.close();
        statement.close();
        // Close the connection to the database
        con.close();

        // Inform user if no results were found
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No matching products found : " + searchTerm, "Information", JOptionPane.INFORMATION_MESSAGE);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "SQL Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } catch (ClassNotFoundException e) {
        JOptionPane.showMessageDialog(this, "Database Driver Not Found: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        ReportDialog reportDialog = new ReportDialog(this);
    reportDialog.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
LogIn loginForm = new LogIn();
    loginForm.setVisible(true);
    
    // Dispose of the current form so it doesn't stay open in the background
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    public class ReportDialog extends JDialog {
    private JTextArea reportArea;
    private JButton submitButton;

    public ReportDialog(JFrame parent) {
        super(parent, "Submit Report", true); // Set modal to true
        setLayout(new BorderLayout(10, 10)); // Use BorderLayout for the dialog

        reportArea = new JTextArea(10, 30); // Create a text area for the report
        add(new JScrollPane(reportArea), BorderLayout.CENTER); // Add scroll bar
       
        submitButton = new JButton("Submit");
        submitButton.addActionListener(new SubmitAction());

        // Add button at the bottom of the dialog
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(submitButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setSize(400, 300); // Set dialog size
        setLocationRelativeTo(parent); // Center the dialog relative to the parent frame
    }

    private class SubmitAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String reportText = reportArea.getText().trim();
            if (reportText.isEmpty()) {
                JOptionPane.showMessageDialog(ReportDialog.this, "Please enter a report.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Code to process the report goes here (e.g., database insertion)
            try {
                // Database connection
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sekantsi2230476", "root", ""); // Update with your DB credentials

                // Insert report into the database
                String sql = "INSERT INTO report (report_text) VALUES (?)"; // Assuming 'report_text' is the column name in the 'report' table
                PreparedStatement statement = con.prepareStatement(sql);
                statement.setString(1, reportText);
                statement.executeUpdate();

                // Clean up
                statement.close();
                con.close();
                
                JOptionPane.showMessageDialog(ReportDialog.this, "Report submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Close the dialog after submission
            } catch (Exception ex) {
                ex.printStackTrace(); // Debugging
                JOptionPane.showMessageDialog(ReportDialog.this, "Error submitting report: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Salesperson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Salesperson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Salesperson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Salesperson.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Salesperson().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}