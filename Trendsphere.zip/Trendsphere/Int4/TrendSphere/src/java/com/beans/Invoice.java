/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.beans;

import java.io.Serializable;
import java.util.Date;
/**
 *
 * @author polok
 */
public class Invoice implements Serializable{
    private int invoiceId;
    private  Date invoiceDate;
    private Product product;
    private User user;

    public Invoice(Date orderDate, Product product, User user) {
        this.invoiceDate = orderDate;
        this.product = product;
        this.user = user;
    }

    public int getOrderId() {
        return invoiceId;
    }

    public void setOrderId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Date getOrderDate() {
        return invoiceDate;
    }

    public void setOrderDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    
}
