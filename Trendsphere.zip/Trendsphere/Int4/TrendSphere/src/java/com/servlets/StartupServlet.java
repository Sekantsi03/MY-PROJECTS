/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.servlets;

import com.beans.Product;
import com.services.ProductService;
import com.services.UserService;
import com.utils.CurrencyUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import java.util.List;

/**
 *
 * @author polok
 */
@WebServlet(name = "StartupServlet", urlPatterns = {"/StartupServlet"}, loadOnStartup = 1)
public class StartupServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        new UserService().createDefaultAdmin();
        ProductService productService = new ProductService();
        List<Product> productList = productService.getAllProducts();
        for (Product product : productList) {
            double malotiValue = CurrencyUtil.convertToMaloti(product.getPrice());
            product.setPrice((float) malotiValue);
        }
        getServletContext().setAttribute("productList", productList);
    }
}
