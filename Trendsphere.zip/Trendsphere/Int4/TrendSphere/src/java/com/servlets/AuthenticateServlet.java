/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.servlets;

import com.beans.Role;
import com.beans.User;
import com.services.RoleService;
import com.services.UserService;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author polok
 */
@WebServlet(name = "AuthenticateServlet", urlPatterns = {"/AuthenticateServlet"})
public class AuthenticateServlet extends HttpServlet {
    
    RoleService roleService = new RoleService();
    UserService userService = new UserService();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("register".equals(action)) {
            String username = request.getParameter("email");
            String password = request.getParameter("password");
            int roleId = 2;
            Role role = roleService.findRoleById(roleId);
            
            boolean isRegistered = userService.registerUser(username, password, role.getRoleID());

            if (isRegistered) {
                response.sendRedirect("auth/login.jsp?status=success&message=You have successfully registed");
            } else {
                response.sendRedirect("auth/register.jsp?status=error&message=Unable to register try another email");
            }
        }      
        else if ("login".equals(action)) {
            String username = request.getParameter("email");
            String password = request.getParameter("password");
            
            User user = userService.loginUser(username, password);
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
    
            if (user != null) {             
                switch(user.getRole().getRoleID()){
                    case 1:
                        response.sendRedirect("admin/dashboard.jsp");
                        break;
                    case 2:
                        response.sendRedirect("customer/dashboard.jsp");
                        break;      
                }             
            } else {
                response.sendRedirect("auth/login.jsp?status=error&message=Invalid credentials");
            }
        }
    
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("logout".equals(action)) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate(); 
            }
            response.sendRedirect("index.jsp"); 
        }
    }
}
