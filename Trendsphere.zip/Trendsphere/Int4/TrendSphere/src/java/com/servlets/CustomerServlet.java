/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.servlets;

import com.beans.CartItem;
import com.beans.Product;
import com.beans.User;
import com.services.OrderService;
import com.services.ProductService;
import com.utils.CurrencyUtil;
import static com.utils.CurrencyUtil.convertToMaloti;
import com.utils.EmailUtil;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author polok
 */
@WebServlet(name = "CustomerServlet", urlPatterns = {"/CustomerServlet"})
public class CustomerServlet extends HttpServlet {
    
    ProductService productService = new ProductService();
    OrderService orderService = new OrderService();
     
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("addToCart".equals(action)) {
            int productId = Integer.parseInt(request.getParameter("productId"));
            HttpSession session = request.getSession();

            List<Product> cart = (List<Product>) session.getAttribute("cart");
            if (cart == null) {
                cart = new ArrayList<>();
            }

            Product product = productService.getProductById(productId);
            String message = "Failed to add product.";

            if (product != null) {
                cart.add(product);
                message = "Product added to cart successfully!";
            }

            session.setAttribute("cart", cart);
            response.sendRedirect("customer/dashboard.jsp?page=home&status=success&message=" + URLEncoder.encode(message, "UTF-8"));
        }
        else if ("removeFromCart".equals(action)) {
            int productId = Integer.parseInt(request.getParameter("productId"));
            HttpSession session = request.getSession();
            List<Product> cart = (List<Product>) session.getAttribute("cart");

            if (cart != null) {
                cart.removeIf(p -> p.getProductId() == productId);
                session.setAttribute("cart", cart); 
            }
            response.sendRedirect("customer/dashboard.jsp?status=success&page=cart&message=" + URLEncoder.encode("Product removed from cart!", "UTF-8"));
        }
        else if ("buy".equals(action)) {
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            List<Product> cart = (List<Product>) session.getAttribute("cart");

            if (cart != null && user != null) {
                boolean allSuccess = true;
                for (Product product : cart) {
                    boolean quantityUpdated = productService.decreaseQuantity(product.getProductId(), 1);

                    if (quantityUpdated) {
                        boolean orderInserted = orderService.insertOrder(
                            new java.sql.Date(new Date().getTime()),
                            product.getProductId(),
                            user.getUserId()
                        );
                        if (!orderInserted) allSuccess = false;
                    } else {
                        allSuccess = false;
                    }
                }
                
                if (allSuccess) {
                    StringBuilder emailBody = new StringBuilder("Thank you for your order!\n\nOrder Details:\n");
                    float total = 0;
                    for (Product product : cart) {
                        double priceInMaloti = convertToMaloti(product.getPrice());
                        total += priceInMaloti;

                        emailBody.append("- ").append(product.getName())
                                 .append(" | Size: ").append(product.getSize())
                                 .append(" | Color: ").append(product.getColor())
                                 .append(" | Price: M").append(String.format("%.2f", priceInMaloti))
                                 .append("\n");
                    }
                    emailBody.append("\nTotal Amount: M").append(String.format("%.2f", total));

                    try {
                        EmailUtil.sendEmail(user.getEmail(), "Order Confirmation", emailBody.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    session.removeAttribute("cart");
                    response.sendRedirect("customer/dashboard.jsp?status=success&page=home&message=Order placed!");
                } else {
                    response.sendRedirect("customer/dashboard.jsp?status=error&page=home&message=Some items couldn't be processed.");
                }
            } else {
                response.sendRedirect("customer/dashboard.jsp?status=error&page=home&message=Cart is empty or user not logged in.");
            }
        }

        else if ("filter".equals(action)) {
            String type = request.getParameter("type");
            String color = request.getParameter("color");
            String sizeStr = request.getParameter("size");
            String minPriceStr = request.getParameter("minPrice");
            String maxPriceStr = request.getParameter("maxPrice");

            List<Product> products = new ArrayList<>();

            if (type != null && !type.isEmpty()) {
                products = productService.getProductsByType(type);
            } else if (color != null && !color.isEmpty()) {
                products = productService.getProductsByColor(color);
            } else if (sizeStr != null && !sizeStr.isEmpty()) {
                int size = Integer.parseInt(sizeStr);
                products = productService.getProductsBySize(size);
            } else if (minPriceStr != null && maxPriceStr != null) {
                float min = Float.parseFloat(minPriceStr);
                float max = Float.parseFloat(maxPriceStr);
                products = productService.getProductsByPriceRange(min, max);
            } else {
                products = productService.getAllProducts();
            }

            request.getSession().setAttribute("productList", products);
            response.sendRedirect("customer/dashboard.jsp?page=home");
        }
        else if("setCurrency".equals(action)){
            String currency = request.getParameter("currency");
            
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("addToCart".equals(action)) {
            int productId = Integer.parseInt(request.getParameter("id"));

            HttpSession session = request.getSession();
            Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");

            if (cart == null) {
                cart = new HashMap<>();
            }

            Product product = productService.getProductById(productId);

            if (product != null && product.getQuantity() > 0) {
                CartItem item = cart.get(productId);

                if (item == null) {
                    cart.put(productId, new CartItem(product, 1));
                } else {
                    item.incrementQuantity();
                }

                session.setAttribute("cart", cart);
                response.sendRedirect("dashboard.jsp?page=cart&status=success&message=Product added to cart!");
            } else {
                response.sendRedirect("dashboard.jsp?page=products&status=error&message=Out of stock!");
            }
        }
        else if("getProducts".equals(action)){
           List<Product> products = new ArrayList<>();
           HttpSession session = request.getSession();
           products = productService.getAllProducts();
           for (Product product : products) {
            double malotiValue = CurrencyUtil.convertToMaloti(product.getPrice());
            product.setPrice((float) malotiValue);
        }
           session.setAttribute("productList", products);
           response.sendRedirect("customer/dashboard.jsp?page=home");
        }

    }

}
