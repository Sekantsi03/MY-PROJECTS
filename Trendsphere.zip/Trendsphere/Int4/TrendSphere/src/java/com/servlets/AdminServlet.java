/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.servlets;

import com.beans.Product;
import com.services.ProductService;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import java.io.File;
import java.net.URLEncoder;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author polok
 */
@MultipartConfig(fileSizeThreshold = 1024 * 1024, maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 10  )
@WebServlet(name = "AdminServlet", urlPatterns = {"/AdminServlet"})
public class AdminServlet extends HttpServlet {
    
    ProductService productService = new ProductService();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("addProduct".equals(action)) {
            String name = request.getParameter("name");
            String type = request.getParameter("type");
            int size = Integer.parseInt(request.getParameter("size"));
            String color = request.getParameter("color");
            float price = Float.parseFloat(request.getParameter("price"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            Part filePart = request.getPart("photo");
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); 
            String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdir();

            String filePath = uploadPath + File.separator + fileName;
            filePart.write(filePath);

            Product product = new Product(name, type, size, color, price, quantity, fileName);
    
            boolean success = productService.saveProduct(product);

            if (success) {
                response.sendRedirect("admin/dashboard.jsp?status=success&message=" + URLEncoder.encode("Product added", "UTF-8"));
            } else {
                response.sendRedirect("admin/dashboard.jsp?status=error&message=" + URLEncoder.encode("Failed to save product.", "UTF-8"));
            }
        } 
        else if("deleteProducts".equals(action)){
            int id = Integer.parseInt(request.getParameter("productId"));

            boolean success = productService.deleteProduct(id);
            if (success) {
                List<Product> products = new ArrayList<>();
                products = productService.getAllProducts();
                HttpSession session = request.getSession();
                session.setAttribute("products", products);
                response.sendRedirect("admin/dashboard.jsp?status=success&message=" + URLEncoder.encode("Product deleted Successfully", "UTF-8"));
            } 
            else {
                response.sendRedirect("admin/dashboard.jsp?status=error&message=" + URLEncoder.encode("Failed to delete product.", "UTF-8"));
            }
        }
        else if ("updateProducts".equals(action)) {
            int productId = Integer.parseInt(request.getParameter("productId"));
            String name = request.getParameter("name");
            String type = request.getParameter("type");
            String color = request.getParameter("color");
            double size = Double.parseDouble(request.getParameter("size"));
            double price = Double.parseDouble(request.getParameter("price"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            boolean isUpdated = productService.updateProduct(productId, name, type, color, size, price, quantity);

            if (isUpdated) {
                List<Product> products = new ArrayList<>();
                products = productService.getAllProducts();
                HttpSession session = request.getSession();
                session.setAttribute("products", products);
                response.sendRedirect("admin/dashboard.jsp?status=success&page=products&message=" + URLEncoder.encode("Product Updated Successfully", "UTF-8"));
            } else {
                response.sendRedirect("admin/dashboard.jsp?status=error&message=" + URLEncoder.encode("Failed to Update product.", "UTF-8"));
            }
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if("getAllProducts".equals(action)){
            List<Product> products = new ArrayList<>();
            products = productService.getAllProducts();
            HttpSession session = request.getSession();
            session.setAttribute("products", products);
            response.sendRedirect("admin/dashboard.jsp?page=products");
        }
    }  
}
