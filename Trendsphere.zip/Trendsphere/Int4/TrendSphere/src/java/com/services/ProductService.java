/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.services;

import com.beans.Product;
import com.utils.Database;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author polok
 */
public class ProductService {
    public boolean saveProduct(Product product) {
        String query = "INSERT INTO products (product_name, type, size, color, price, quantity, photo_location) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, product.getName());
            stmt.setString(2, product.getType());
            stmt.setInt(3, product.getSize());
            stmt.setString(4, product.getColor());
            stmt.setFloat(5, product.getPrice());
            stmt.setInt(6, product.getQuantity());
            stmt.setString(7, product.getPhoto());

            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM products";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String name = rs.getString("product_name");
                String type = rs.getString("type");
                int size = rs.getInt("size");
                String color = rs.getString("color");
                float price = rs.getFloat("price");
                int quantity = rs.getInt("quantity");
                String photoLocation = rs.getString("photo_location");

                Product product = new Product(productId, name, type, size, color, price, quantity, photoLocation);
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
    public boolean deleteProduct(int productId) {
        String query = "DELETE FROM products WHERE product_id = ?";
        try (Connection conn = Database.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, productId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean updateProduct(int productId, String name, String type, String color, double size, double price, int quantity) {
        String query = "UPDATE products SET product_name = ?, type = ?, color = ?, size = ?, price = ?, quantity = ? WHERE product_id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, type);
            stmt.setString(3, color);
            stmt.setDouble(4, size);
            stmt.setDouble(5, price);
            stmt.setInt(6, quantity);
            stmt.setInt(7, productId);

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean decreaseQuantity(int productId, int quantity) {
        String sql = "UPDATE products SET quantity = quantity - ? WHERE product_id = ? AND quantity >= ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, quantity);
            stmt.setInt(2, productId);
            stmt.setInt(3, quantity);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static double convertCurrency(double usdPrice, String targetCurrency) {
        switch (targetCurrency) {
            case "LSL": return usdPrice * 18.50;
            case "ZAR": return usdPrice * 18.50;
            case "EUR": return usdPrice * 0.92;
            default: return usdPrice;
        }
    }

    public List<Product> getProductsByType(String type) {
        String query = "SELECT * FROM products WHERE type = ?";
        return getFilteredProducts(query, type);
    }
    public List<Product> getProductsByColor(String color) {
        String query = "SELECT * FROM products WHERE color = ?";
        return getFilteredProducts(query, color);
    }
    public List<Product> getProductsBySize(int size) {
        String query = "SELECT * FROM products WHERE size = ?";
        return getFilteredProducts(query, size);
    }
    public List<Product> getProductsByPrice(float price) {
        String query = "SELECT * FROM products WHERE price = ?";
        return getFilteredProducts(query, price);
    }
    public List<Product> getProductsByPriceRange(float minPrice, float maxPrice) {
        List<Product> productList = new ArrayList<>();
        String query = "SELECT * FROM products WHERE price BETWEEN ? AND ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setFloat(1, minPrice);
            stmt.setFloat(2, maxPrice);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                productList.add(mapResultSetToProduct(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return productList;
    }
    private List<Product> getFilteredProducts(String query, Object value) {
        List<Product> productList = new ArrayList<>();

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setObject(1, value);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                productList.add(mapResultSetToProduct(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return productList;
    }
    private Product mapResultSetToProduct(ResultSet rs) throws SQLException {
        Product product = new Product();
        product.setProductId(rs.getInt("product_id"));
        product.setName(rs.getString("product_name"));
        product.setType(rs.getString("type"));
        product.setSize(rs.getInt("size"));
        product.setColor(rs.getString("color"));
        product.setPrice(rs.getFloat("price"));
        product.setQuantity(rs.getInt("quantity"));
        product.setPhoto(rs.getString("photo_location"));
        return product;
    }
    public boolean buyProduct(int productId) {
        String selectQuery = "SELECT quantity FROM products WHERE product_id = ?";
        String updateQuery = "UPDATE products SET quantity = quantity - 1 WHERE product_id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement selectStmt = conn.prepareStatement(selectQuery)) {

            selectStmt.setInt(1, productId);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                int quantity = rs.getInt("quantity");
                if (quantity > 0) {
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                        updateStmt.setInt(1, productId);
                        int rows = updateStmt.executeUpdate();
                        return rows > 0;
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public Product getProductById(int id) {
        String query = "SELECT * FROM products WHERE product_id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("product_name"));
                product.setType(rs.getString("type"));
                product.setSize(rs.getInt("size"));
                product.setColor(rs.getString("color"));
                product.setPrice(rs.getFloat("price"));
                product.setQuantity(rs.getInt("quantity"));
                product.setPhoto(rs.getString("photo_location"));

                return product;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
