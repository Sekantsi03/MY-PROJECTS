/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.services;

import java.sql.*;
import com.utils.Database;

/**
 *
 * @author polok
 */
public class OrderService {
    
    public boolean insertOrder(Date date, int productId, int userId) {
        String sql = "INSERT INTO orders (order_date, product_id, user_id) VALUES (?, ?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            java.sql.Date sqlDate = new java.sql.Date(date.getTime());

            stmt.setDate(1, sqlDate);
            stmt.setInt(2, productId);
            stmt.setInt(3, userId);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }  
}
