/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.services;

import com.beans.Role;
import com.beans.User;
import com.utils.Database;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author polok
 */
public class UserService {
    RoleService roleService = new RoleService();
    public User findUserById(int id){
        User user = null;
        String query = "SELECT * FROM users WHERE user_id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int roleId = rs.getInt("role_id");
                Role role = roleService.findRoleById(roleId);
                
                user = new User(rs.getString("email"), rs.getString("password"), role); 
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }
    public User findUserByEmail(String email){
        User user = null;
        String query = "SELECT * FROM users WHERE user_id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int roleId = rs.getInt("role_id");
                Role role = roleService.findRoleById(roleId);
                
                user = new User(rs.getString("email"), rs.getString("password"), role); 
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }
    public boolean registerUser(String username, String password, int roleId) {
        String query = "INSERT INTO users (email, password, role_id) VALUES (?, ?, ?)";
        Role role = roleService.findRoleById(roleId);
        
        String hashedPassword = hashPassword(password);

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, hashedPassword);
            stmt.setInt(3, role.getRoleID());

            int rows = stmt.executeUpdate();
            return rows > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public User loginUser(String username, String plainPassword) {
        String query = "SELECT user_id, email, password, role_id FROM users WHERE email = ?";

        try (Connection conn = Database.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("user_id");
                String uname = rs.getString("email");
                String hashedPassword = rs.getString("password");
                int roleId = rs.getInt("role_id");

                if (verifyPassword(plainPassword, hashedPassword)) {
                    Role role = roleService.findRoleById(roleId); 
                    return new User(id, uname, hashedPassword, role);
                } else {
                    System.out.println("Incorrect password.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean createDefaultAdmin() {
        String checkQuery = "SELECT * FROM users WHERE email = ?";
        String insertQuery = "INSERT INTO users (email, password, role_id) VALUES (?, ?, ?)";
        Role role = roleService.findRoleById(1);
        String hashedPassword = hashPassword("admin");

        try (Connection conn = Database.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

            checkStmt.setString(1, "admin@gmail.com");
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                System.out.println("ℹ️ Default admin already exists.");
                return false;
            }

            try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                insertStmt.setString(1, "admin@gmail.com");
                insertStmt.setString(2, hashedPassword);
                insertStmt.setInt(3, role.getRoleID());

                int rows = insertStmt.executeUpdate();
                System.out.println("Default admin created.");
                return rows > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    
    private String hashPassword(String password) {
            try {
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hashedBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                for (byte b : hashedBytes) {
                    sb.append(String.format("%02x", b));
                }
                return sb.toString();
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("Failed to hash password", e);
            }
        }
        public boolean verifyPassword(String enteredPassword, String storedHash) {
        String enteredPasswordHash = hashPassword(enteredPassword);
        return enteredPasswordHash.equals(storedHash);
    }
}
