/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.services;

import com.beans.Role;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.utils.Database;

/**
 *
 * @author polok
 */
public class RoleService {
    
    public Role findRoleById(int id) {
        Role role = null;
        String query = "SELECT * FROM roles WHERE role_id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                role = new Role(rs.getInt("role_id"), rs.getString("role_name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return role;
    }
}
