/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.utils;

/**
 *
 * @author polok
 */
public class CurrencyUtil {
    private static final double USD_TO_LSL = 18.50;

    public static double convertToMaloti(double usdAmount) {
        return usdAmount * USD_TO_LSL;
    }
}
